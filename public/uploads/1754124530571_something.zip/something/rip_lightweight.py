import requests
from requests.adapters import HTTPAdapter, Retry
from datetime import datetime, timezone
import pytz
import time
from utils.batoto import Batoto
from concurrent.futures import ThreadPoolExecutor
import logging
import time
from bs4 import BeautifulSoup
import os
os.environ["VIPS_CONCURRENCY"] = "8"
import pyvips


def get_ist_time():
    return datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d %H:%M:%S')

session = requests.Session()

COOKIE = ""
PROXIES = {
    "http": "",
    "https": ""
}

ANDROID_HEADERS = {
    "Accept": "application/panda+json",
    "Accept-Encoding": "gzip",
    "Connection": "Keep-Alive",
    "Content-Type": "application/json; charset=utf-8",
    "Host": "api.tapas.io",
    "User-Agent": "okhttp 31104; OS Version 9; OnePlus A5000",
    "X-Device-Type": "ANDROID",
    "X-Device-Uuid": "c5dc18c224115999",
    "X-LANG-CODE": "en",
    "X-Offset-Time": "330",
    "X-User-Id": "16955775",
    "X-Auth-Token": "eyJhbGciOiJIUzUxMiJ9.eyJwIjoia3hqcCIsImMiOjE3MzMzNzUyODAwMDAsImQiOiJjNWRjMThjMjI0MTE1OTk5IiwidCI6IkFORFJPSUQiLCJ2IjoiMiIsImgiOiJOIiwiaSI6IjE2OTU1Nzc1In0.VMVF5XJmmNxniUKoDUzFmWlN6XVz-QH8NTWEGI9H1tl4ZyFYQxETqYkwUe2KjYe7eB5n-28LsMzbvY8B7X0cPg"
}


adapter = HTTPAdapter(
    pool_connections=10000,
    pool_maxsize=10000
)

session.mount("http://", adapter)
session.mount("https://", adapter)

session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'Cookie': COOKIE
})


start_time = datetime.now()
batoto = Batoto()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)


def has_time_passed(target_time_str):
    target_time = datetime.fromisoformat(
        target_time_str.rstrip('Z')).replace(tzinfo=timezone.utc)
    current_time = datetime.now(timezone.utc)

    res = current_time > target_time
    while not res in (True, False):
        res = current_time > target_time
        time.sleep(1)
    return res

def get_images(series_id, episode_id):
    try:
        response = requests.get(
            f"https://api.tapas.io/v4/series/{series_id}/episodes/{episode_id}?ics=true",
            headers=ANDROID_HEADERS,
        )

        if response.status_code == 404:
            return []

        content = response.json()["contents"]

        if not content:
            response = requests.get(
                f"https://api.tapas.io/v4/series/{series_id}/episodes/{episode_id}",
                headers=ANDROID_HEADERS,
                proxies=PROXIES,
            )

            if response.status_code == 404:
                return []

        return [item["file_url"] for item in content]
    except:
        return []

def fetch_image(order, img_url, headers):
    file_extension = "webp"
    try:
        data = session.get(img_url, headers=headers, timeout=3).content
    except:
        return fetch_image(order, img_url, headers)

    if not data:
        return fetch_image(order, img_url, headers)


    img = pyvips.Image.new_from_buffer(data, "")
    output_buffer = img.write_to_buffer('.webp', Q=55, effort=0, lossless=False, smart_subsample=False)

    return order, {"data": output_buffer, "file_extension": file_extension}


def parallel_fetch_images(image_urls, headers):
    image_content_dict = {}
    with ThreadPoolExecutor(max_workers=8) as executor:
        tasks = [
            executor.submit(fetch_image, order, img_url, headers)
            for order, img_url in enumerate(image_urls, start=1)
        ]
        for task in tasks:
            order, content = task.result()
            if content:
                image_content_dict[order] = content

    return image_content_dict

episode_id = "3518142" #input("Episode ID: ").strip()
batoto_id = "192262" #input("Batoto ID: ").strip()
series_id = "304546" #input("Series ID: ").strip()
print(f"Ripping: '{episode_id}' on Batoto ID: '{batoto_id}'")
target_date_str = "2025-07-07T06:39:03Z"

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'pragma': 'no-cache',
    'priority': 'u=0, i',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}

while not has_time_passed(target_date_str):
    time.sleep(0.1)

logging.info(f"Waiting for Episode to be available...")
ep_url = f"https://tapas.io/episode/{episode_id}"

while True:
    start_total = time.perf_counter()
    image_urls = []

    while not image_urls:
        image_urls = get_images(series_id, episode_id)
    
    if not image_urls:
        print(f"{get_ist_time()} - Waiting for episode to be available...")
    else:
        break
print(f"Fetched image URLs for episode {episode_id}: {len(image_urls)} images in {time.perf_counter() - start_total:.2f} seconds.")

ep_title = "Episode 6"

def fix_page(soup):
    series_title_element = soup.select_one('p.center-info__title.center-info__title--small:not(.js-ep-title)')
    print(f"Series Title Element: {series_title_element}")
    series_title = series_title_element.text.strip() if series_title_element else None

    img_element = soup.find('a', class_='thumb js-series-btn').find('img')
    if img_element:
        img_url = img_element.get('src')
    else:
        img_url = None

    description_body = soup.find('div', class_='info-body__center')
    if description_body:
        description = description_body.text.strip()
    else:
        description = None    

    batoto.edit(batoto_id, title=series_title, img_url=img_url, summary=description)

import threading

def edit_thread():
    return
    try:
        fix_page(soup)
    except Exception as e:
        logging.error(f"Error in edit_thread: {e}")

thread = threading.Thread(target=edit_thread)
thread.start()

success = False
start = time.perf_counter()
logging.info("Downloading images...")
image_content_dict = parallel_fetch_images(image_urls, headers)
logging.info(f"Images downloaded in {time.perf_counter() - start:.2f} seconds.")

start = time.perf_counter()
logging.info("Uploading images to Batoto...")
batoto.upload(batoto_id, image_content_dict, chapter_number=6, display_name='Episode 6')
logging.info(f"Upload complete in {time.perf_counter() - start:.2f} seconds.")

logging.info(f"Total execution time: {time.perf_counter() - start_total:.2f} seconds.")
success = True