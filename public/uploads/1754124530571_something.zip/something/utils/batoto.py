import requests
import re
import os
import json
import random
from requests_toolbelt.multipart.encoder import MultipartEncoder
import random
import string
import base64
from datetime import datetime, timezone
import pytz
import time
import uuid
import secrets
import bs4
from tqdm import tqdm
import threading
from requests.adapters import HTTPAdapter
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.qwik_bs import get_batoto_info

CHARACTERS = string.ascii_lowercase + string.ascii_uppercase + string.digits

class Batoto:
    def __init__(self, account="ellie"):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0'
        })
        
        with open('data/accounts.json', 'r') as f:
            accounts = json.load(f)
            
        if not account in accounts:
            account = "ellie"

        adapter = HTTPAdapter(pool_connections=1000, pool_maxsize=10000)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

        self.session.cookies.update({"cookie": accounts[account]})
        self.page_id_map = {}
        self.lock = threading.Lock()
        self.edited = False
        
    def get_task_id(self, sid):
        resp = self.session.get(f'https://bato.to/publish/chapter-editor?comicid={sid}')
        print(resp.url)
        match = re.search(r'upload id:\s*<!--t=\w+-->(.*?)<!---->', resp.text)
        
        return match.group(1)
    
    
    def upload_file(self, task_id, file_path):
        resp = None
        filename = os.path.basename(file_path)
        boundary_string = ''.join(random.choice(CHARACTERS) for i in range(16))
        encoder = MultipartEncoder(
            fields={
                'content': (filename, open(file_path, 'rb'), 'application/octet-stream'),
                'origFilename': filename,
                'total': '1',
                'pid': '0',
                'fidL': str(uuid.uuid4()),
                'dropSn': '1',
                'uploadId': task_id,
            },
            boundary=f'------WebKitFormBoundary{boundary_string}'
        )
        while not resp:
            resp = self.session.post("https://bato.to/ap1/upload-comic-pages", data=encoder, headers={'Content-Type': encoder.content_type})  
            if not resp.status_code == 200:
                resp = None 

        return filename, resp.json()['files'][0]['iid']
    
    def upload_image_data(self, task_id, index, image_data):
        resp = None
        extension = image_data['file_extension']
        binary_content = image_data['data']
        filename = f"{str(index).zfill(3)}.{extension}"
        
        boundary_string = ''.join(random.choice(CHARACTERS) for i in range(16))
        encoder = MultipartEncoder(
            fields={
                'content': (filename, binary_content, 'application/octet-stream'),
                'origFilename': filename,
                'total': '1',
                'pid': '0',
                'fidL': str(uuid.uuid4()),
                'dropSn': '1',
                'uploadId': task_id,
                'chunk': '1'
            },
            boundary=f'------WebKitFormBoundary{boundary_string}'
        )
        
        while not resp:
            resp = self.session.post("https://bato.to/ap1/upload-chapter-image", data=encoder, headers={'Content-Type': encoder.content_type})  
            if resp:
                if not resp.status_code == 200:
                    resp = None 
            else:
                print("No response")
                resp = None
            
        track_id = resp.json()['trackId']
        
        resp = None
        payload = {
            "uploadId": task_id,
            "trackIds": [track_id]
        }
        
        while not resp:
            resp = self.session.post("https://bato.to/ap1/pub-chapter-upload-process-stats", json=payload)
            
            if resp:
                if not resp.status_code == 200:
                    resp = None
                    continue
                if not resp.json().get('results', {}).get(track_id, {}).get('files', []):
                    resp = None
            else:
                resp = None
                
                
        return filename, resp.json()['results'][track_id]['files'][0]['iid']
    
    def get_page_ids(self, data):
        return [file['iid'] for file in sorted(data['res']['files'], key=lambda x: int(x['orig'].split('/')[-1].split('.')[0]))]
    
    def submit_chapter(self, task_id, chapter_number, file_ids, display_name=None):
        
        tries = 0

        json_data = {
            "chapterId": "",
            "serial": str(chapter_number),
            "volume": "",
            "dname": display_name if display_name else "",
            "title": "",
            "isFinal": False,
            "sfw_by_user": None,
            "dbStatus": "hidden",
            "groupIds": [],
            "editNote": "",
            "uploadId": task_id,
            "fiids": file_ids
        }
        
        self.session.post("https://bato.to/ap1/pub-chapter-save", json=json_data)
        
    def get_tapas_details(self, series_id, tapas_session):
        response = tapas_session.get(f"https://tapas.io/series/{series_id}/info")
        if "verify-age" in response.url:
            description = None
            img_url = None
        else:
            tapas_soup = bs4.BeautifulSoup(response.text, "html.parser")
            description_body = tapas_soup.find("span", class_="description__body")
            
            if description_body:
                description = description_body.text.strip()
            else:
                description = None

            img_element = tapas_soup.find("a", class_="thumb js-thumbnail").find("img")
            if img_element:
                img_url = img_element.get("src")
            else:
                img_url = None
                
        return description, img_url
        
    def upload(self, sid, image_content_dict, chapter_number, display_name=None, title=None, summary=None, cover=None, tapas_session=None, series_id=None):
        self.page_id_map = {}
        self.edited = False
        task_id = self.get_task_id(sid) 
        upload_results = {}
        upload_start_time = time.perf_counter()
        edit_future = None
        print(title)
        with ThreadPoolExecutor(max_workers=1000) as executor:
            futures = []
            if title or cover or summary:
                edit_future = executor.submit(self.edit, sid, title=title, img_url=cover, summary=summary, tapas_session=tapas_session, series_id=series_id)
            
            for index, image_data in image_content_dict.items():
                future = executor.submit(self.upload_image_data, task_id, index, image_data)
                futures.append(future)
            
            for future in tqdm(as_completed(futures), total=len(futures), desc="Uploading"):
                filename, page_id = future.result()  # Capture the result
                upload_results[filename] = page_id
        print(f"Finished uploading images for task_id: {task_id} in {time.perf_counter() - upload_start_time:.4f} seconds")
        self.page_id_map = upload_results
        sorting_start_time = time.perf_counter()
        sorted_files = sorted(self.page_id_map.items(), key=lambda x: int(re.search(r'\d+', x[0]).group()))
        print(f"Sorted files for task_id: {task_id} in {time.perf_counter() - sorting_start_time:.4f} seconds")
        submit_start_time = time.perf_counter()
        self.submit_chapter(task_id, chapter_number, [file[1] for file in sorted_files], display_name)
        print(f"Submitted chapter for task_id: {task_id} in {time.perf_counter() - submit_start_time:.4f} seconds")

        return []
        
    def create_series(self, title, img_url, genres, authors, artists, associated_names, orig="ko", resources="", summary=None):
        self.session.get("https://bato.to/editor-subject")

        img = requests.get(img_url)
        image_bytes = img.content
        bsf = base64.b64encode(image_bytes).decode("utf-8")

        json_data = {
            "subjectIid": 0,
            "info": {
                "type": None,
                "orig": orig,
                "lang": "en",
                "title": title,
                "suffix": None,
                "altNames": associated_names,
                "authors": authors,
                "artists": artists,
                "mpcrs": None,
                "genres": genres,
                "direction": "ttb",
                "release": None,
                "uploadStatus": None,
                "pubFrom": None,
                "pubTill": None,
                "summary": summary,
                "notices": None,
                "resources": resources
            },
            "status": "hidden",
            "imageBase64": f"data:image/jpeg;base64,{bsf}",
            "recap": ""
        }

        r = self.session.post("https://bato.to/ajax/editor-subject-submit", json=json_data)
        r_json = r.json()

        perm_data = {
            "subjectIid": r_json['res']['subjectIid'],
            "permissions": {
                "who_can_upload_ep": "972562",
                "who_can_edit_epis": "972562",
                "who_can_edit_info": "972562",
                "who_can_edit_perm": "972562",
                "is_owner": True,
                "is_moder": 0,
                "is_admin": 0,
                "you_can_upload_ep": True,
                "you_can_edit_epis": True,
                "you_can_edit_info": True,
                "you_can_edit_perm": True
            }
        }

        self.session.post('https://bato.to/ajax/subject-permissions-submit', data=json.dumps(perm_data))

        return r_json['res']['subjectIid']
    
    def upload_comic_image(self, sid, img_url):
        img_data = requests.get(img_url).content
        multipart_data = MultipartEncoder(
            fields={
                'comicId': str(sid),
                'content': ('file.jpg', img_data, 'image/jpeg')
            }
        )
        
        resp = self.session.post("https://bato.to/ap1/upload-comic-image", data=multipart_data, headers={'Content-Type': multipart_data.content_type})
        
        while not resp.status_code == 200:
            resp = self.session.post("https://bato.to/ap1/upload-comic-image", data=multipart_data, headers={'Content-Type': multipart_data.content_type})
            
        return resp.json()['name']
    
    def edit(self, sid, title=None, img_url=None, summary=None, tapas_session=None, series_id=None):
        print(title)
        if (not img_url and not summary) and series_id and tapas_session:
            summary, img_url = self.get_tapas_details(series_id, tapas_session)
        print(title)
        
        r = self.session.get(f"https://bato.to/publish/comic-info?comicId={sid}")
        series_info = get_batoto_info(r.text)
        print(series_info)
        
        if title:
            series_info['name'] = title + ' [Official]'
        if summary:
            series_info['summary'] = summary

        if img_url:
            series_info['cover'] = self.upload_comic_image(sid, img_url)

        print(series_info)

        resp = self.session.post("https://bato.to/ap1/pub-comic-save-info", json=series_info)
        print(resp.text)
        self.edited = True
        
        