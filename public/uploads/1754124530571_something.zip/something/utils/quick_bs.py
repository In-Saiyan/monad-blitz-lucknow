import json
import random
from bs4 import BeautifulSoup
from typing import Any, Dict, List, Optional


class QwikJsonParser:
    def __init__(self, json_data: Dict[str, Any]):
        self.json_data = json_data
        self.parsed_objects = [None] * len(json_data.get("objs", []))

    def parse_number(self, value: str) -> int:
        """Convert base-36 encoded number to integer."""
        return int(value, 36) if value else 0

    def get_object(self, index: Any, parent: Optional[Any] = None) -> Any:
        """Recursively parse and decode Qwik JSON objects."""
        # Handle string indices
        if isinstance(index, str):
            try:
                # Convert to numeric index
                index = self.parse_number(index)
            except ValueError:
                return index  # Return as-is if can't convert

        # Ensure valid index
        if index < 0 or index >= len(self.parsed_objects):
            return index

        # Return cached object if already parsed
        if self.parsed_objects[index] is not None:
            return self.parsed_objects[index]

        # Retrieve raw value
        raw_value = self.json_data["objs"][index]

        # Decode based on type
        if isinstance(raw_value, list):
            # List of references
            obj = [self.get_object(item, parent) for item in raw_value]
        elif isinstance(raw_value, dict):
            # Dictionary with potentially referenced values
            obj = {}
            for key, value in raw_value.items():
                obj[key] = self.get_object(value, obj)
        elif isinstance(raw_value, str):
            # Try to decode or keep as string
            obj = raw_value
        else:
            obj = raw_value

        # Cache parsed object
        self.parsed_objects[index] = obj
        return obj

    def parse(self) -> Dict[str, Any]:
        """Main parsing method."""
        return {
            "objs": [
                self.get_object(i) for i in range(len(self.json_data.get("objs", [])))
            ],
            "contexts": self.json_data.get("ctx", {}),
            "refs": self.json_data.get("refs", {}),
            "subscriptions": self.json_data.get("subs", []),
        }


def load_qwik_json(json_file_path: str) -> Dict[str, Any]:
    """Load Qwik JSON from file."""
    with open(json_file_path, "r") as f:
        return json.load(f)


def get_batoto_info(html_content: str):
    soup = BeautifulSoup(html_content, "html.parser")

    qwik_json_string = soup.find("script", type="qwik/json").text
    qwik_json = json.loads(qwik_json_string)

    parser = QwikJsonParser(qwik_json)
    parsed_data = parser.parse()

    to_exist = ["origLang", "tranLang", "summary", "extraInfo"]
    found_dict = None
    for item in parsed_data["objs"]:
        if not isinstance(item, dict):
            continue

        if all(key in item for key in to_exist):
            found_dict = item
            break

    if not found_dict:
        return None
    
    with open('data/bs.json', 'r', encoding='utf-8') as f:
        bs_data = json.load(f)

    return {
        "comicId": found_dict["id"],
        "name": found_dict["name"],
        "cover": "",
        "lang": found_dict['tranlang'],
        "orig": found_dict['origLang'],
        "genres": found_dict['genres'],
        "altNames": found_dict['altNames'],
        "authors": found_dict['authors'],
        "artists": found_dict['artists'],
        "publishers": found_dict['publishers'],
        "direction": found_dict['readDirection'],
        "release": found_dict['originalStatus'],
        "release_local": found_dict['uploadStatus'],
        "pubFrom": found_dict['originalPubFrom'],
        "pubTill": found_dict['originalPubTill'],
        "summary": found_dict['summary'],
        "extraInfo": found_dict['extraInfo'],
        "dbStatus": found_dict['dbStatus'],
        "editNote": random.choice(bs_data),
    }
