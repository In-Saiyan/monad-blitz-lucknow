# Rip Lightweight Batoto (Rust)

A Rust port of the Python manga ripper for downloading episodes from Tapas and uploading to Batoto.

## Features

- **Concurrent Processing**: Download and process multiple images simultaneously
- **WebP Optimization**: Automatic image conversion to WebP format with quality control
- **Robust Error Handling**: Retry mechanisms for network operations
- **CLI Interface**: Easy-to-use command-line interface with clap
- **Async/Await**: Fully asynchronous using Tokio for high performance

## Prerequisites

1. **Rust**: Install Rust from [rustup.rs](https://rustup.rs/)
2. **Account Data**: Configure your Batoto account cookie in `data/accounts.json`

## Setup

1. Clone or navigate to the project directory
2. Edit `data/accounts.json` with your Batoto account cookie:
   ```json
   {
     "ellie": "your_actual_cookie_value_here"
   }
   ```
3. Build the project:
   ```bash
   cargo build --release
   ```

## Usage

### Basic Usage

```bash
cargo run -- --episode-id "3518142" --batoto-id "192262" --series-id "304546"
```

### With All Options

```bash
cargo run -- \
  --episode-id "3518142" \
  --batoto-id "192262" \
  --series-id "304546" \
  --target-date "2025-07-07T06:39:03Z" \
  --chapter-number 6 \
  --display-name "Episode 6" \
  --max-workers 16
```

### Command Line Arguments

- `--episode-id, -e`: Episode ID to rip (required)
- `--batoto-id, -b`: Batoto ID for the series (required)  
- `--series-id, -s`: Series ID from Tapas (required)
- `--target-date, -t`: Target date when episode becomes available (ISO 8601 format)
- `--chapter-number, -c`: Chapter number (default: 1)
- `--display-name, -d`: Display name for the chapter
- `--max-workers`: Maximum concurrent downloads (default: 8)

## Architecture

The Rust version is organized into several modules:

### Core Modules

- **`main.rs`**: CLI interface and main application logic
- **`batoto.rs`**: Batoto API client for uploading chapters and managing series
- **`tapas_client.rs`**: Tapas API client for fetching episodes and images
- **`image_processor.rs`**: Image processing and WebP conversion
- **`qwik_parser.rs`**: Parser for Batoto's Qwik JSON format

### Key Improvements over Python Version

1. **Performance**: 
   - Rust's zero-cost abstractions and memory safety
   - Efficient async/await with Tokio
   - Better memory management for image processing

2. **Concurrency**:
   - Semaphore-based concurrent image downloads
   - Parallel image processing
   - Non-blocking I/O operations

3. **Error Handling**:
   - Comprehensive error types with `anyhow`
   - Retry mechanisms for network operations
   - Graceful failure handling

4. **Type Safety**:
   - Compile-time guarantees
   - Structured data with serde
   - No runtime type errors

## Configuration Files

### `data/accounts.json`
Contains Batoto account cookies:
```json
{
  "account_name": "cookie_value"
}
```

### `data/bs.json`
Contains random edit notes for Batoto submissions:
```json
[
  "Updated with latest chapter",
  "Fixed formatting issues",
  ...
]
```

## Dependencies

Key dependencies used:

- **tokio**: Async runtime
- **reqwest**: HTTP client with multipart support
- **serde/serde_json**: Serialization
- **chrono/chrono-tz**: Date/time handling
- **image**: Image processing
- **clap**: CLI argument parsing
- **anyhow**: Error handling
- **scraper**: HTML parsing
- **uuid**: UUID generation
- **rand**: Random number generation

## Building

### Debug Build
```bash
cargo build
```

### Release Build (Optimized)
```bash
cargo build --release
```

### Running Tests
```bash
cargo test
```

## Example Workflow

1. Wait for target date (if specified)
2. Fetch episode images from Tapas API
3. Download images concurrently
4. Process images to WebP format
5. Upload to Batoto with metadata
6. Submit chapter

## Logging

Set log level with environment variable:
```bash
RUST_LOG=debug cargo run -- [args]
```

Log levels: `error`, `warn`, `info`, `debug`, `trace`

## Error Recovery

The application includes several retry mechanisms:

- Network requests retry on failure
- Image downloads retry with exponential backoff
- Upload operations retry until success
- Graceful handling of temporary API failures

## Performance Tuning

Adjust concurrency based on your system:

- `--max-workers 4`: Conservative (low bandwidth/CPU)
- `--max-workers 8`: Default (balanced)
- `--max-workers 16`: Aggressive (high-end systems)

## Differences from Python Version

### Removed Features
- `fix_page()` function (was disabled in Python version)
- PyVips dependency (replaced with Rust image crate)
- Some hardcoded values are now configurable

### Enhanced Features
- Better concurrent image processing
- More robust error handling
- Structured configuration
- CLI argument parsing
- Comprehensive logging

## Contributing

1. Follow Rust formatting standards (`cargo fmt`)
2. Run clippy for lints (`cargo clippy`)
3. Ensure tests pass (`cargo test`)
4. Update documentation for new features
