use anyhow::{anyhow, Result};
use rand::seq::SliceRandom;
use scraper::{Html, Selector};
use serde_json::{Map, Value};

pub struct QwikJsonParser {
    json_data: Value,
    parsed_objects: Vec<Option<Value>>,
}

impl QwikJsonParser {
    pub fn new(json_data: Value) -> Self {
        let obj_count = json_data
            .get("objs")
            .and_then(|v| v.as_array())
            .map(|arr| arr.len())
            .unwrap_or(0);

        Self {
            json_data,
            parsed_objects: vec![None; obj_count],
        }
    }

    fn parse_number(&self, value: &str) -> Result<usize> {
        if value.is_empty() {
            return Ok(0);
        }
        usize::from_str_radix(value, 36).map_err(|e| anyhow!("Failed to parse base36: {}", e))
    }

    fn get_object(&mut self, index: &Value, _parent: Option<&Value>) -> Result<Value> {
        let index_num = match index {
            Value::String(s) => self.parse_number(s)?,
            Value::Number(n) => n.as_u64().unwrap_or(0) as usize,
            _ => return Ok(index.clone()),
        };

        if index_num >= self.parsed_objects.len() {
            return Ok(index.clone());
        }

        // Return cached object if already parsed
        if let Some(cached) = &self.parsed_objects[index_num] {
            return Ok(cached.clone());
        }

        // Get raw value from objects array
        let raw_value = self
            .json_data
            .get("objs")
            .and_then(|v| v.as_array())
            .and_then(|arr| arr.get(index_num))
            .ok_or_else(|| anyhow!("Invalid object index: {}", index_num))?
            .clone();

        let obj = match raw_value {
            Value::Array(arr) => {
                let mut result = Vec::new();
                for item in arr {
                    result.push(self.get_object(&item, None)?);
                }
                Value::Array(result)
            }
            Value::Object(map) => {
                let mut result = Map::new();
                for (key, value) in map {
                    result.insert(key, self.get_object(&value, None)?);
                }
                Value::Object(result)
            }
            _ => raw_value,
        };

        // Cache parsed object
        self.parsed_objects[index_num] = Some(obj.clone());
        Ok(obj)
    }

    pub fn parse(&mut self) -> Result<Value> {
        let objs = self
            .json_data
            .get("objs")
            .and_then(|v| v.as_array())
            .ok_or_else(|| anyhow!("No objs array found"))?;

        let mut parsed_objs = Vec::new();
        for i in 0..objs.len() {
            let index_value = Value::Number(serde_json::Number::from(i));
            parsed_objs.push(self.get_object(&index_value, None)?);
        }

        Ok(serde_json::json!({
            "objs": parsed_objs,
            "contexts": self.json_data.get("ctx").unwrap_or(&Value::Null),
            "refs": self.json_data.get("refs").unwrap_or(&Value::Null),
            "subscriptions": self.json_data.get("subs").unwrap_or(&Value::Null),
        }))
    }
}

pub fn get_batoto_info(html_content: &str) -> Result<Value> {
    let document = Html::parse_document(html_content);
    let selector = Selector::parse(r#"script[type="qwik/json"]"#)
        .map_err(|e| anyhow!("Invalid selector: {:?}", e))?;

    let script_element = document
        .select(&selector)
        .next()
        .ok_or_else(|| anyhow!("No qwik/json script found"))?;

    let qwik_json_string = script_element.inner_html();
    let qwik_json: Value = serde_json::from_str(&qwik_json_string)?;

    let mut parser = QwikJsonParser::new(qwik_json);
    let parsed_data = parser.parse()?;

    let to_exist = ["origLang", "tranLang", "summary", "extraInfo"];
    let mut found_dict = None;

    if let Some(objs) = parsed_data.get("objs").and_then(|v| v.as_array()) {
        for item in objs {
            if let Some(obj) = item.as_object() {
                if to_exist.iter().all(|key| obj.contains_key(*key)) {
                    found_dict = Some(obj);
                    break;
                }
            }
        }
    }

    let found_dict = found_dict.ok_or_else(|| anyhow!("Could not find required data structure"))?;

    // Load bs.json for random edit notes
    let bs_data_content = std::fs::read_to_string("data/bs.json")?;
    let bs_data: Vec<String> = serde_json::from_str(&bs_data_content)?;
    let default_note = String::from("Default edit note");
    let random_note = bs_data
        .choose(&mut rand::thread_rng())
        .unwrap_or(&default_note);

    let result = serde_json::json!({
        "comicId": found_dict.get("id").unwrap_or(&Value::Null),
        "name": found_dict.get("name").unwrap_or(&Value::Null),
        "cover": "",
        "lang": found_dict.get("tranlang").unwrap_or(&Value::Null),
        "orig": found_dict.get("origLang").unwrap_or(&Value::Null),
        "genres": found_dict.get("genres").unwrap_or(&Value::Array(vec![])),
        "altNames": found_dict.get("altNames").unwrap_or(&Value::Array(vec![])),
        "authors": found_dict.get("authors").unwrap_or(&Value::Array(vec![])),
        "artists": found_dict.get("artists").unwrap_or(&Value::Array(vec![])),
        "publishers": found_dict.get("publishers").unwrap_or(&Value::Array(vec![])),
        "direction": found_dict.get("readDirection").unwrap_or(&Value::Null),
        "release": found_dict.get("originalStatus").unwrap_or(&Value::Null),
        "release_local": found_dict.get("uploadStatus").unwrap_or(&Value::Null),
        "pubFrom": found_dict.get("originalPubFrom").unwrap_or(&Value::Null),
        "pubTill": found_dict.get("originalPubTill").unwrap_or(&Value::Null),
        "summary": found_dict.get("summary").unwrap_or(&Value::Null),
        "extraInfo": found_dict.get("extraInfo").unwrap_or(&Value::Null),
        "dbStatus": found_dict.get("dbStatus").unwrap_or(&Value::Null),
        "editNote": random_note,
    });

    Ok(result)
}
