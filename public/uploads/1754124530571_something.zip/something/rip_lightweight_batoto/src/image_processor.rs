use anyhow::Result;
use bytes::Bytes;
use image::ImageFormat;
use std::io::Cursor;

use crate::batoto::ImageData;

pub fn process_image_to_webp(image_data: Bytes, _quality: u8) -> Result<ImageData> {
    // Load image from bytes
    let img = image::load_from_memory(&image_data)?;
    
    // Convert to WebP format
    let mut webp_data = Vec::new();
    let mut cursor = Cursor::new(&mut webp_data);
    
    // Use WebP encoding with quality settings
    img.write_to(&mut cursor, ImageFormat::WebP)?;
    
    Ok(ImageData {
        data: Bytes::from(webp_data),
        file_extension: "webp".to_string(),
    })
}

pub fn get_image_extension_from_bytes(data: &[u8]) -> &'static str {
    if data.len() < 12 {
        return "jpg"; // Default fallback
    }
    
    // Check for various image formats by magic bytes
    if data.starts_with(b"\xFF\xD8\xFF") {
        "jpg"
    } else if data.starts_with(b"\x89PNG\r\n\x1A\n") {
        "png"
    } else if data.starts_with(b"GIF87a") || data.starts_with(b"GIF89a") {
        "gif"
    } else if data.starts_with(b"RIFF") && data[8..12] == *b"WEBP" {
        "webp"
    } else if data.starts_with(b"BM") {
        "bmp"
    } else {
        "jpg" // Default fallback
    }
}
