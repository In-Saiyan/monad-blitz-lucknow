use anyhow::{anyhow, Result};
use bytes::Bytes;
use reqwest::{multipart, Client};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Instant;
use tokio::sync::Semaphore;
use uuid::Uuid;

use crate::qwik_parser::get_batoto_info;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatotoAccount {
    pub cookie: String,
}

#[derive(Debug, Clone)]
pub struct ImageData {
    pub data: Bytes,
    pub file_extension: String,
}

pub struct Batoto {
    client: Client,
    cookie: String,
    page_id_map: Arc<Mutex<HashMap<String, String>>>,
    edited: Arc<Mutex<bool>>,
}

impl Batoto {
    pub async fn new(account: Option<&str>) -> Result<Self> {
        let account_name = account.unwrap_or("ellie");
        
        // Load accounts from JSON file
        let accounts_data = tokio::fs::read_to_string("data/accounts.json").await?;
        let accounts: HashMap<String, String> = serde_json::from_str(&accounts_data)?;
        
        let cookie = accounts
            .get(account_name)
            .ok_or_else(|| anyhow!("Account '{}' not found", account_name))?;

        let client = Client::builder()
            .user_agent("Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0")
            .build()?;

        Ok(Batoto {
            client,
            cookie: cookie.clone(),
            page_id_map: Arc::new(Mutex::new(HashMap::new())),
            edited: Arc::new(Mutex::new(false)),
        })
    }

    pub async fn get_task_id(&self, sid: &str) -> Result<String> {
        let url = format!("https://bato.to/publish/chapter-editor?comicId={}", sid);
        let response = self.client.get(&url)
            .header("Cookie", &self.cookie)
            .send().await?;
        let text = response.text().await?;

        // Extract task ID using regex pattern
        let pattern = r"upload id:\s*<!--t=\w+-->(.*?)<!---->";
        let re = regex::Regex::new(pattern)?;
        
        if let Some(captures) = re.captures(&text) {
            Ok(captures.get(1).unwrap().as_str().to_string())
        } else {
            Err(anyhow!("Could not find task ID in response"))
        }
    }

    pub async fn upload_image_data(
        &self,
        task_id: &str,
        index: usize,
        image_data: &ImageData,
    ) -> Result<(String, String)> {
        let extension = &image_data.file_extension;
        let filename = format!("{:03}.{}", index, extension);

        let mut response = None;
        while response.is_none() {
            let form = multipart::Form::new()
                .part(
                    "content",
                    multipart::Part::bytes(image_data.data.to_vec())
                        .file_name(filename.clone())
                        .mime_str("application/octet-stream")?,
                )
                .text("origFilename", filename.clone())
                .text("total", "1")
                .text("pid", "0")
                .text("fidL", Uuid::new_v4().to_string())
                .text("dropSn", "1")
                .text("uploadId", task_id.to_string())
                .text("chunk", "1");

            match self
                .client
                .post("https://bato.to/ap1/upload-chapter-image")
                .header("Cookie", &self.cookie)
                .multipart(form)
                .send()
                .await
            {
                Ok(resp) if resp.status().is_success() => {
                    response = Some(resp);
                }
                _ => {
                    log::warn!("Upload failed, retrying...");
                    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                }
            }
        }

        let resp_json: Value = response.unwrap().json().await?;
        let track_id = resp_json["trackId"]
            .as_str()
            .ok_or_else(|| anyhow!("No trackId in response"))?;

        // Process upload stats
        let payload = serde_json::json!({
            "uploadId": task_id,
            "trackIds": [track_id]
        });

        let mut stats_response = None;
        while stats_response.is_none() {
            match self
                .client
                .post("https://bato.to/ap1/pub-chapter-upload-process-stats")
                .header("Cookie", &self.cookie)
                .json(&payload)
                .send()
                .await
            {
                Ok(resp) if resp.status().is_success() => {
                    let json: Value = resp.json().await?;
                    if let Some(files) = json["results"][track_id]["files"].as_array() {
                        if !files.is_empty() {
                            stats_response = Some(json);
                        }
                    }
                }
                _ => {
                    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                }
            }
        }

        let stats_json = stats_response.unwrap();
        println!("Upload stats: {}", stats_json); //TODO remove // works
        let iid = stats_json["results"][track_id]["files"][0]["iid"]
            .as_u64()
            .ok_or_else(|| anyhow!("No iid in response"))?;

        Ok((filename, iid.to_string()))
    }

    pub async fn submit_chapter(
        &self,
        task_id: &str,
        chapter_number: u32,
        file_ids: Vec<String>,
        display_name: Option<&str>,
    ) -> Result<()> {
        let json_data = serde_json::json!({
            "chapterId": "",
            "serial": chapter_number.to_string(),
            "volume": "",
            "dname": display_name.unwrap_or(""),
            "title": "",
            "isFinal": false,
            "sfw_by_user": null,
            "dbStatus": "hidden",
            "groupIds": [],
            "editNote": "",
            "uploadId": task_id,
            "fiids": file_ids
        });
        
        println!("Submitting chapter with data: {}", json_data);

        self.client
            .post("https://bato.to/ap1/pub-chapter-save")
            .header("Cookie", &self.cookie)
            .json(&json_data)
            .send()
            .await?;

        Ok(())
    }

    pub async fn upload_comic_image(&self, sid: &str, img_url: &str) -> Result<String> {
        let img_response = self.client.get(img_url).send().await?;
        let img_data = img_response.bytes().await?;

        let mut response = None;
        while response.is_none() {
            let form = multipart::Form::new()
                .text("comicId", sid.to_string())
                .part(
                    "content",
                    multipart::Part::bytes(img_data.to_vec())
                        .file_name("file.jpg")
                        .mime_str("image/jpeg")?,
                );

            match self
                .client
                .post("https://bato.to/ap1/upload-comic-image")
                .header("Cookie", &self.cookie)
                .multipart(form)
                .send()
                .await
            {
                Ok(resp) if resp.status().is_success() => {
                    response = Some(resp);
                }
                _ => {
                    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                }
            }
        }

        let resp_json: Value = response.unwrap().json().await?;
        Ok(resp_json["name"]
            .as_str()
            .ok_or_else(|| anyhow!("No name in response"))?
            .to_string())
    }

    pub async fn edit(
        &self,
        sid: &str,
        title: Option<&str>,
        img_url: Option<&str>,
        summary: Option<&str>,
    ) -> Result<()> {
        let url = format!("https://bato.to/publish/comic-info?comicId={}", sid);
        let response = self.client.get(&url)
            .header("Cookie", &self.cookie)
            .send().await?;
        let text = response.text().await?;

        let mut series_info = get_batoto_info(&text)?;

        if let Some(title) = title {
            series_info["name"] = serde_json::Value::String(format!("{} [Official]", title));
        }

        if let Some(summary) = summary {
            series_info["summary"] = serde_json::Value::String(summary.to_string());
        }

        if let Some(img_url) = img_url {
            let cover_name = self.upload_comic_image(sid, img_url).await?;
            series_info["cover"] = serde_json::Value::String(cover_name);
        }

        self.client
            .post("https://bato.to/ap1/pub-comic-save-info")
            .header("Cookie", &self.cookie)
            .json(&series_info)
            .send()
            .await?;

        *self.edited.lock().unwrap() = true;
        Ok(())
    }

    pub async fn upload(
        &self,
        sid: &str,
        image_content_dict: HashMap<usize, ImageData>,
        chapter_number: u32,
        display_name: Option<&str>,
        title: Option<&str>,
        summary: Option<&str>,
        cover: Option<&str>,
    ) -> Result<()> {
        let task_id = self.get_task_id(sid).await?;
        log::info!("Got task ID: {}", task_id);

        let upload_start = Instant::now();
        
        // Upload edit info concurrently if provided
        if title.is_some() || cover.is_some() || summary.is_some() {
            let batoto_clone = self.clone();
            let sid_clone = sid.to_string();
            let title_clone = title.map(|s| s.to_string());
            let summary_clone = summary.map(|s| s.to_string());
            let cover_clone = cover.map(|s| s.to_string());
            
            tokio::spawn(async move {
                if let Err(e) = batoto_clone.edit(
                    &sid_clone,
                    title_clone.as_deref(),
                    cover_clone.as_deref(),
                    summary_clone.as_deref(),
                ).await {
                    log::error!("Error in edit: {}", e);
                }
            });
        }

        // Upload images concurrently
        let semaphore = Arc::new(Semaphore::new(1000)); // Limit concurrent uploads
        let mut handles = Vec::new();
        let upload_results = Arc::new(Mutex::new(HashMap::new()));

        for (index, image_data) in image_content_dict {
            let permit = semaphore.clone().acquire_owned().await?;
            let batoto_clone = self.clone();
            let task_id_clone = task_id.clone();
            let upload_results_clone = upload_results.clone();

            let handle = tokio::spawn(async move {
                let _permit = permit; // Keep permit alive
                match batoto_clone
                    .upload_image_data(&task_id_clone, index, &image_data)
                    .await
                {
                    Ok((filename, page_id)) => {
                      println!("Uploaded image {}: {}", filename, page_id); //TODO remove
                        upload_results_clone
                            .lock()
                            .unwrap()
                            .insert(filename, page_id);
                    }
                    Err(e) => log::error!("Upload failed for index {}: {}", index, e),
                }
            });

            handles.push(handle);
        }

        // Wait for all uploads to complete
        for handle in handles {
            handle.await?;
        }

        let upload_duration = upload_start.elapsed();
        log::info!("Finished uploading images in {:.2?}", upload_duration);

        // Sort files and submit chapter
        let sorting_start = Instant::now();
        let upload_results = upload_results.lock().unwrap();
        let mut sorted_files: Vec<_> = upload_results.iter().collect();
        println!("Sorting {:?} files...", sorted_files); //TODO remove
        sorted_files.sort_by_key(|(filename, _)| {
            // Extract number from filename
            filename
                .chars()
                .filter(|c| c.is_ascii_digit())
                .collect::<String>()
                .parse::<u32>()
                .unwrap_or(0)
        });

        let file_ids: Vec<String> = sorted_files.iter().map(|(_, id)| (*id).clone()).collect();
        
        let sorting_duration = sorting_start.elapsed();
        log::info!("Sorted files in {:.2?}", sorting_duration);

        let submit_start = Instant::now();
        self.submit_chapter(&task_id, chapter_number, file_ids, display_name)
            .await?;
        let submit_duration = submit_start.elapsed();
        log::info!("Submitted chapter in {:.2?}", submit_duration);

        Ok(())
    }
}

impl Clone for Batoto {
    fn clone(&self) -> Self {
        Batoto {
            client: self.client.clone(),
            cookie: self.cookie.clone(),
            page_id_map: Arc::clone(&self.page_id_map),
            edited: Arc::clone(&self.edited),
        }
    }
}
