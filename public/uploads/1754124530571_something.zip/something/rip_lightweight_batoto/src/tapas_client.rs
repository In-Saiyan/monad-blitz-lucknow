use anyhow::{anyhow, Result};
use chrono::{DateTime, Utc};
use reqwest::Client;
use serde_json::Value;
use std::collections::HashMap;

#[derive(Clone)]
pub struct TapasClient {
    client: Client,
    android_headers: HashMap<String, String>,
    proxies: Option<HashMap<String, String>>,
}

impl TapasClient {
    pub fn new() -> Self {
        let mut android_headers = HashMap::new();
        android_headers.insert("Accept".to_string(), "application/panda+json".to_string());
        android_headers.insert("Accept-Encoding".to_string(), "gzip".to_string());
        android_headers.insert("Connection".to_string(), "Keep-Alive".to_string());
        android_headers.insert("Content-Type".to_string(), "application/json; charset=utf-8".to_string());
        android_headers.insert("Host".to_string(), "api.tapas.io".to_string());
        android_headers.insert("User-Agent".to_string(), "okhttp 31104; OS Version 9; OnePlus A5000".to_string());
        android_headers.insert("X-Device-Type".to_string(), "ANDROID".to_string());
        android_headers.insert("X-Device-Uuid".to_string(), "c5dc18c224115999".to_string());
        android_headers.insert("X-LANG-CODE".to_string(), "en".to_string());
        android_headers.insert("X-Offset-Time".to_string(), "330".to_string());
        android_headers.insert("X-User-Id".to_string(), "16955775".to_string());
        android_headers.insert("X-Auth-Token".to_string(), "eyJhbGciOiJIUzUxMiJ9.eyJwIjoia3hqcCIsImMiOjE3MzMzNzUyODAwMDAsImQiOiJjNWRjMThjMjI0MTE1OTk5IiwidCI6IkFORFJPSUQiLCJ2IjoiMiIsImgiOiJOIiwiaSI6IjE2OTU1Nzc1In0.VMVF5XJmmNxniUKoDUzFmWlN6XVz-QH8NTWEGI9H1tl4ZyFYQxETqYkwUe2KjYe7eB5n-28LsMzbvY8B7X0cPg".to_string());

        let client = Client::builder()
            .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36")
            .build()
            .expect("Failed to create HTTP client");

        Self {
            client,
            android_headers,
            proxies: None,
        }
    }

    pub fn with_proxies(mut self, proxies: HashMap<String, String>) -> Self {
        self.proxies = Some(proxies);
        self
    }

    pub async fn get_images(&self, series_id: &str, episode_id: &str) -> Result<Vec<String>> {
        let url = format!(
            "https://api.tapas.io/v4/series/{}/episodes/{}?ics=true",
            series_id, episode_id
        );

        let mut request = self.client.get(&url);
        for (key, value) in &self.android_headers {
            request = request.header(key, value);
        }

        let response = request.send().await?;

        if response.status() == 404 {
            return Ok(vec![]);
        }

        let json: Value = response.json().await?;
        
        if let Some(contents) = json.get("contents").and_then(|v| v.as_array()) {
            if !contents.is_empty() {
                return Ok(contents
                    .iter()
                    .filter_map(|item| item.get("file_url").and_then(|url| url.as_str()))
                    .map(|s| s.to_string())
                    .collect());
            }
        }

        // Fallback request without ics parameter
        let fallback_url = format!(
            "https://api.tapas.io/v4/series/{}/episodes/{}",
            series_id, episode_id
        );

        let mut fallback_request = self.client.get(&fallback_url);
        for (key, value) in &self.android_headers {
            fallback_request = fallback_request.header(key, value);
        }

        // Add proxy if configured
        if let Some(ref _proxies) = self.proxies {
            // Note: reqwest doesn't support per-request proxies easily
            // This would need to be handled at the client level
        }

        let fallback_response = fallback_request.send().await?;

        if fallback_response.status() == 404 {
            return Ok(vec![]);
        }

        let fallback_json: Value = fallback_response.json().await?;
        
        if let Some(contents) = fallback_json.get("contents").and_then(|v| v.as_array()) {
            Ok(contents
                .iter()
                .filter_map(|item| item.get("file_url").and_then(|url| url.as_str()))
                .map(|s| s.to_string())
                .collect())
        } else {
            Ok(vec![])
        }
    }

    pub async fn fetch_image(&self, img_url: &str) -> Result<bytes::Bytes> {
        let headers = [
            ("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"),
            ("accept-language", "en-US,en;q=0.9"),
            ("cache-control", "no-cache"),
            ("pragma", "no-cache"),
            ("priority", "u=0, i"),
            ("sec-ch-ua", r#""Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24""#),
            ("sec-ch-ua-mobile", "?0"),
            ("sec-ch-ua-platform", r#""Windows""#),
            ("sec-fetch-dest", "document"),
            ("sec-fetch-mode", "navigate"),
            ("sec-fetch-site", "none"),
            ("sec-fetch-user", "?1"),
            ("upgrade-insecure-requests", "1"),
            ("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"),
        ];

        let mut request = self.client.get(img_url);
        for (key, value) in &headers {
            request = request.header(*key, *value);
        }

        let response = request.send().await?;
        let data = response.bytes().await?;

        if data.is_empty() {
            return Err(anyhow!("Empty response for image URL: {}", img_url));
        }

        Ok(data)
    }
}

pub fn has_time_passed(target_time_str: &str) -> Result<bool> {
    let target_time = DateTime::parse_from_rfc3339(
        &(target_time_str.trim_end_matches('Z').to_string() + "+00:00")
    )?;
    let current_time = Utc::now();
    
    Ok(current_time > target_time.with_timezone(&Utc))
}

pub fn get_ist_time() -> String {
    use chrono_tz::Asia::Kolkata;
    let now = Utc::now().with_timezone(&Kolkata);
    now.format("%Y-%m-%d %H:%M:%S").to_string()
}
