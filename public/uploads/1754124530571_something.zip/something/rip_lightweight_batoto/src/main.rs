mod batoto;
mod image_processor;
mod qwik_parser;
mod tapas_client;

use anyhow::Result;
use batoto::{Batoto, ImageData};
use clap::Parser;
use futures::future::join_all;
use log::{error, info};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;
use tapas_client::{get_ist_time, has_time_passed, TapasClient};
use tokio::sync::Semaphore;

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Episode ID to rip
    #[arg(short, long)]
    episode_id: String,

    /// Batoto ID for the series
    #[arg(short, long)]
    batoto_id: String,

    /// Series ID from Tapas
    #[arg(short, long)]
    series_id: String,

    /// Target date when episode becomes available (ISO 8601 format)
    #[arg(short, long)]
    target_date: Option<String>,

    /// Chapter number
    #[arg(short, long, default_value = "1")]
    chapter_number: u32,

    /// Display name for the chapter
    #[arg(short, long)]
    display_name: Option<String>,

    /// Maximum concurrent downloads
    #[arg(long, default_value = "8")]
    max_workers: usize,
}

async fn fetch_image_with_processing(
    order: usize,
    img_url: String,
    tapas_client: Arc<TapasClient>,
) -> Result<(usize, ImageData)> {
    let data = tapas_client.fetch_image(&img_url).await?;
    
    if data.is_empty() {
        return Err(anyhow::anyhow!("Empty image data for URL: {}", img_url));
    }

    // Process image to WebP format with quality 55
    let processed_image = image_processor::process_image_to_webp(data, 55)?;
    
    Ok((order, processed_image))
}

async fn parallel_fetch_images(
    image_urls: Vec<String>,
    tapas_client: Arc<TapasClient>,
    max_workers: usize,
) -> HashMap<usize, ImageData> {
    let semaphore = Arc::new(Semaphore::new(max_workers));
    let mut tasks = Vec::new();

    for (order, img_url) in image_urls.into_iter().enumerate() {
        let permit = semaphore.clone().acquire_owned().await.unwrap();
        let tapas_client_clone = Arc::clone(&tapas_client);
        
        let task = tokio::spawn(async move {
            let _permit = permit; // Keep permit alive
            fetch_image_with_processing(order + 1, img_url, tapas_client_clone).await
        });
        
        tasks.push(task);
    }

    let mut image_content_dict = HashMap::new();
    let results = join_all(tasks).await;
    
    for result in results {
        match result {
            Ok(Ok((order, content))) => {
                image_content_dict.insert(order, content);
            }
            Ok(Err(e)) => {
                error!("Failed to fetch image: {}", e);
            }
            Err(e) => {
                error!("Task failed: {}", e);
            }
        }
    }

    image_content_dict
}

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    let args = Args::parse();

    info!(
        "Ripping: '{}' on Batoto ID: '{}'",
        args.episode_id, args.batoto_id
    );

    // Wait for target date if specified
    if let Some(target_date_str) = &args.target_date {
        while !has_time_passed(target_date_str)? {
            tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
        }
    }

    let start_time = Instant::now();
    let tapas_client = Arc::new(TapasClient::new());
    let batoto = Batoto::new(None).await?;

    info!("Waiting for Episode to be available...");

    // Wait for images to become available
    let mut image_urls = Vec::new();
    let start_total = Instant::now();

    while image_urls.is_empty() {
        match tapas_client
            .get_images(&args.series_id, &args.episode_id)
            .await
        {
            Ok(urls) if !urls.is_empty() => {
                image_urls = vec![urls[0].clone()]; // Use the first URL for simplicity
            }
            Ok(_) => {
                info!("{} - Waiting for episode to be available...", get_ist_time());
                // tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
                continue;
            }
            Err(e) => {
                error!("Error fetching images: {}", e);
                // tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
                continue;
            }
        }
    }

    info!(
        "Fetched image URLs for episode {}: {} images in {:.2?}",
        args.episode_id,
        image_urls.len(),
        start_total.elapsed()
    );

    // Download and process images
    let download_start = Instant::now();
    info!("Downloading images...");
    let image_content_dict = parallel_fetch_images(
        image_urls,
        Arc::clone(&tapas_client),
        args.max_workers,
    ).await;
    
    info!(
        "Images downloaded in {:.2?}",
        download_start.elapsed()
    );

    // Upload to Batoto
    let upload_start = Instant::now();
    info!("Uploading images to Batoto...");
    
    batoto
        .upload(
            &args.batoto_id,
            image_content_dict,
            args.chapter_number,
            args.display_name.as_deref(),
            None, // title
            None, // summary  
            None, // cover
        )
        .await?;

    info!(
        "Upload complete in {:.2?}",
        upload_start.elapsed()
    );

    info!(
        "Total execution time: {:.2?}",
        start_time.elapsed()
    );

    Ok(())
}
